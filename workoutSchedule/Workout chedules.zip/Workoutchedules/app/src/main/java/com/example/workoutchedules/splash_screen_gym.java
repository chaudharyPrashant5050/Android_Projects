package com.example.workoutchedules;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class splash_screen_gym extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen_gym);

        View decorView = getWindow().getDecorView();
        int uioption = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uioption);

        Thread td =  new Thread(){
            public void run(){

                try{
                    sleep(2500);

                }catch (Exception ex){
                    ex.printStackTrace();
                }finally{

                    Intent intent = new Intent(splash_screen_gym.this,MainActivity.class);
                    startActivity(intent);
                    finish();

                }
            }
        };
        td.start();
    }
}