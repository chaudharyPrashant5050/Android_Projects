package com.example.workoutchedules;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class BeginnerLevel extends AppCompatActivity {



    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beginner_level);

        String []workOut = new String[]{"Chest","Back","Lag","Shoulder","Tricep","Bicep","Rest"};




        TextView []day = new TextView[]{ findViewById(R.id.workoutMon),findViewById(R.id.workoutTue),findViewById(R.id.workoutWed),findViewById(R.id.workoutThu),findViewById(R.id.workoutFri),findViewById(R.id.workoutSat),findViewById(R.id.workoutSun)};


        for(int i=0;i<workOut.length;i++){
            day[i].setText(workOut[i]);

        }



        Button btn = findViewById(R.id.button0);
        btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                Collections.shuffle(Arrays.asList(workOut));
                int flagChest=1, flagBack=1;
            while(true) {
                for (int i = 0; i < workOut.length; i++) {
                    if (workOut[i].equals("Chest")) {

                        if ((i != 0) && (i != (workOut.length - 1))) {
                            if ((workOut[i - 1].equals("Shoulder")) || (workOut[i + 1].equals("Shoulder"))) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagChest = 0;

                            }else{
                                flagChest =1;
                            }
                            if (workOut[i - 1].equals("Tricep") || workOut[i + 1].equals("Tricep")) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagChest =0;

                            }else{
                                flagChest =1;
                            }


                        } else if (i == 0) {
                            if (workOut[i + 1].equals("Shoulder") || workOut[i + 1].equals("Tricep")) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagChest=0;

                            }else{
                                flagChest =1;
                            }
                        } else if (i == workOut.length - 1) {
                            if (workOut[i - 1].equals("Shoulder") || workOut[i - 1].equals("Tricep")) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagChest =0;
                            }else{
                                flagChest =1;
                            }
                        }


                    }


                    //checking for back

                    if (workOut[i].equals("Back")) {

                        if ((i != 0) && (i != (workOut.length - 1))) {
                            if ((workOut[i - 1].equals("Bicep")) || (workOut[i + 1].equals("Bicep"))) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagBack = 0;

                            }else{
                                flagBack =1;
                            }


                        } else if (i == 0) {
                            if (workOut[i + 1].equals("Bicep")) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagBack = 0;

                            }else{
                                flagBack =1;
                            }
                        } else if (i == workOut.length - 1) {
                            if (workOut[i - 1].equals("Bicep")) {
                                Collections.shuffle(Arrays.asList(workOut));
                                flagBack = 0;
                            }else{
                                flagBack =1;
                            }
                        }
                    }
                }
                if(flagBack == 1 && flagChest == 1){
                    break;
                }



            }
                for(int i=0;i<workOut.length;i++){

                    if(workOut[i].equals("Rest")){
                        day[i].setTextColor(R.color.green);
                        day[i].setText(workOut[i]);

                    }else{
                        day[i].setText(workOut[i]);

                    }



                }

                }







        });

        ImageView screenSort = findViewById(R.id.takeScreen);

        screenSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap;
                View v1 = findViewById(R.id.root);// get ur root view id
                v1.setDrawingCacheEnabled(true);
                bitmap = Bitmap.createBitmap(v1.getDrawingCache());
                v1.setDrawingCacheEnabled(false);

                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 40, bytes);
                File f = new File(Environment.getExternalStorageDirectory()
                        + File.separator + "test.jpg");
                try {
                    f.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                FileOutputStream fo = null;
                try {
                    fo = new FileOutputStream(f);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                try {
                    fo.write(bytes.toByteArray());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    fo.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });


    }
}